from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from pathlib import Path

source1 = "https://www.selver.ee/piim-2-5-tere-1-l"
source2 = "https://ecoop.ee/et/toode/12606857-tere-piim-25-1l-dvitamiiniga"
source3 = "https://www.barbora.ee/toode/piim-tere-2-5-proc-1-l"

# create a webdriver object for chrome-option and configure
wait_imp = 10
CO = webdriver.ChromeOptions()
CO.add_experimental_option('useAutomationExtension', False)
CO.add_argument('--ignore-certificate-errors')
CO.add_argument('--start-minimized')
wd = webdriver.Chrome(r'C:\Users\Orange\PycharmProjects\pythonProject\Piima hind\Piima hind\chromedriver.exe',options=CO)
print ("*************************************************************************** \n")
print("                     Starting Program, Please wait ..... \n")
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM = 1
print ("Connecting to selver")
wd.get(source1)
wd.implicitly_wait(wait_imp)

xpath2 = 'ProductName'
xpath1 = 'ProductPrice'
#f_price = wd.find_element_by_xpath('//*[@id="product"]/div[3]/div/div[1]/div[1]/div/text()') ei tööta?
f_price = wd.find_element(By.CLASS_NAME, xpath1) #töötab?
pr_name = wd.find_element(By.CLASS_NAME, xpath2) #töötab?
product = pr_name.text
r_price = f_price.text

print (" ---> Successfully retrieved the price from selver \n")
print (r_price[1:])
time.sleep(2)
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM += 1

print("Connecting to Coop")
wd.get(source2)
wd.implicitly_wait(wait_imp)
 
a_name = wd.find_element(By.TAG_NAME, "h1")
a_price = wd.find_element(By.CLASS_NAME, "base")
 
raw_p = a_price.text
print (raw_p[2:8])
print (" ---> Successfully retrieved the price from Coop \n")
time.sleep(2)

MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM += 1

print("Connecting to Maxima(barbora)")
wd.get(source3)
wd.implicitly_wait(wait_imp)
c_name = wd.find_element(By.TAG_NAME, "h1")
c_price = wd.find_element(By.CLASS_NAME, "b-product-price-current-number")
raw_c = c_price.text
print (raw_c[1:7])
print (" ---> Successfully retrieved the price from Croma\n")
time.sleep(2)

 # Final display
print ("#------------------------------------------------------------------------#")
print ("Price for [{}] on all websites, Prices are in eur \n".format(product))
print("Price available at Selver is: 0"+r_price[1:])
print("  Price available at Coop is: "+"0."+raw_p[2:8])
print("   Price available at Maxima(barbora) is: "+raw_c[1:7]+"€")
driver.close()


a = r_price + " Selver"
b = raw_p + " Coop"
c = raw_c + " Maxima(barbora)"
def maximum(a, b, c):
  
    if (a >= b) and (a >= c):
        largest = a
  
    elif (b >= a) and (b >= c):
        largest = b
    else:
        largest = c
          
    return largest
print("\n " + maximum(a, b, c) + " on odavaim")




#kasutatud abi:
#lehekülg, mis oli baas, millele lisasin oma muudatused ja parandused: kaotasin kuidagi ära.
#lehekülg mille abil ma sain parandusi teha ja lõppetada: https://selenium-python.readthedocs.io/locating-elements.html